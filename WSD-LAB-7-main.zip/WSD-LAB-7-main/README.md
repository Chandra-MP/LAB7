# WSD-LAB-7
Create JSON file based on your domain with minimum six entities. You should access JSON file  using Angular JS and apply the following filter operations   1.Apply minimum 6 filter attributes in your JSON file 2.Create minimum 2 custom filters 3.You should have search option for all your JSON fields
